﻿using System;

namespace CarManufacturer
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            var make = Console.ReadLine();
            var model1 = Console.ReadLine();
            var year = int.Parse(Console.ReadLine());
            var fuelQuantity = double.Parse(Console.ReadLine());
            var fuelConsumption = double.Parse(Console.ReadLine());

            var firstCar = new Car();
            var seccondCar = new Car(make, model1, year);
            var thirdCar = new Car(make, model1, year, fuelQuantity, fuelConsumption);

            Console.WriteLine(firstCar.WhoAmI());
            Console.WriteLine();
            Console.WriteLine(seccondCar.WhoAmI());
            Console.WriteLine();
            Console.WriteLine(thirdCar.WhoAmI());
        }
    }
}
