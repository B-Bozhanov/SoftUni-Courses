﻿using System;

namespace CarManufacturer
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            var tires = new Tire[]
            {
                new Tire(1, 2.50),
                new Tire(1, 2.55),
                new Tire(2, 2.20),
                new Tire(2, 2.19)
            };

            var engine = new Engine(300, 3000);

            var audi = new Car("Audi", "A6", 2006, 75, 10, engine, tires);

            Console.WriteLine(audi.Engine);
        }
    }
}
