﻿using System;

namespace CarManufacturer
{
    public class StartUp
    {
        static void Main(string[] args)
        {
           Car car = new Car();
            car.Make = "BMW";
            car.Model = "330";
            car.Year = 2008;
            car.FuelQuantity = 45.50;
            car.FuelConsumption = 9.5;
            Console.WriteLine(car.WhoAmI());
        }
    }
}
