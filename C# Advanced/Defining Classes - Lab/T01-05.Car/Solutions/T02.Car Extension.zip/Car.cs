﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CarManufacturer
{
    public class Car
    {
        private string make;
        private string model;
        private int year;
        private double fuelQuantity;
        private double fuelConsumption;

        public string Make { get; set; }
        public string Model { get; set; }
        public int Year { get; set; }
        public double FuelQuantity { get; set; }
        public double FuelConsumption { get; set; }

        public void Drive(double distance)
        {
            var consumption = FuelConsumption / 100 * distance;

            if (FuelQuantity >= consumption)
            {
                FuelQuantity -= consumption;
            }
            else
            {
                Console.WriteLine("Not enough fuel to perform this trip!");
            }
        }
        public string WhoAmI()
        {
            var carInfo = new StringBuilder();

            carInfo.AppendLine($"Make: {Make}");
            carInfo.AppendLine($"Model: {Model}");
            carInfo.AppendLine($"Year: {Year}");
            carInfo.Append($"Fuel: {FuelQuantity:f2}");

            return carInfo.ToString().Trim();
        }
    }
}
